================================================================================
RKDevInfoWriteTool-rkdevelop.exe
Mail:lsh@rock-chips.com
================================================================================
[2021-07-20]1.3.0
1 fix ta open file fail
[2021-06-28]1.2.9
1 add hdmirx hdcp write & TA encryption key
