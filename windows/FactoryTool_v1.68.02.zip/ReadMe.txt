================================================================================
factoryTool
Mail:lsh@rock-chips.com
================================================================================
[2018-09-10]1.68.01
1、exit if no efuce when checking efuse
[2018-09-10]1.68
1、add check efuse before burn efuse
2、remove redundant codes
