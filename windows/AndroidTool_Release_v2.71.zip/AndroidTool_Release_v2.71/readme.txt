v2.71 revision(20190821):
1.fix download image at last partition bug up
2.optimize the progress of downloading
