v2.71 revision(20190821):
1.fix download image at last partition bug up
2.optimize the progress of downloading

v2.72 revision(20200113):
1.fix erase flash is timeout on nor flash up

v2.73 revision(20200520):
1.support with exporting com log

v2.74 revision(20200723):
1.take small slice to erase nor flash

v2.75 revision(20200915):
1.fix virtual list grid msg collision

v2.76 revision(20200925):
1.complete to download new idblock

v2.78 revision(20201102):
1.support to create download list from parameter

v2.79 revision(20201111):
1.support new loader format

v2.8 revision(20210104):
1.fix chunk size beyond 4g in sparse download

v2.81 revision(20210128)
1.support to list storage and switch storage

