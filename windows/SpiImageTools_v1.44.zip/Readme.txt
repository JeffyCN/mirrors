The documenet for SpiImageTools.exe is located in FactoryTool_****.zip
