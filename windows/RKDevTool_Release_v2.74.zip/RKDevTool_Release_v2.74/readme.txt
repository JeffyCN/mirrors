v2.71 revision(20190821):
1.fix download image at last partition bug up
2.optimize the progress of downloading

v2.72 revision(20200113):
1.fix erase flash is timeout on nor flash up

v2.73 revision(20200520):
1.support with exporting com log

v2.74 revision(20200723):
1.take small slice to erase nor flash

